## -----------------------------------------------------------------------------

data(iris)

library(ggplot2)
library(drewcurves)
library(tidyr)
library(dplyr)

## Show first elements of dataset
head(iris)

## Andrews plot with no group.
drewcurves(iris[, -5])

## Andrews plot with species as group.
drewcurves(iris, group = 5)

## Return dataframe instead of plot.
drewcurves(iris, group = 5, return_dataframe  = TRUE) %>%
    head()

## Modify the x limits (as long as the interval length is 2pi).
drewcurves(iris, group = 5, xlim = c(0, 2*pi))

## Add other elements from ggplot to the plot
drewcurves(iris, group = 5) +
    ylim(c(-1, 3)) +
    ggtitle("Andrews plot", sub = "This is a subtitle") +
    theme_bw() +
    scale_colour_brewer(palette = "Set1")


## ----eval = FALSE-------------------------------------------------------------
# 
# data(iris)
# 
# library(ggplot2)
# library(drewcurves)
# library(andrews)
# library(tidyr)
# library(dplyr)
# 
# ## Show first elements of dataset
# head(iris)
# 
# ## Andrews plot with no group.
# drewcurves(iris[, -5])
# 
# ## Andrews plot with species as group.
# drewcurves(iris, group = 5)
# 
# ## Return dataframe instead of plot.
# drewcurves(iris, group = 5, return_dataframe  = TRUE) %>%
#     head()
# 
# ## Modify the x limits (as long as the interval length is 2pi).
# drewcurves(iris, group = 5, xlim = c(0, 2*pi))
# 
# ## Add other elements from ggplot to the plot
# drewcurves(iris, group = 5) +
#     ylim(c(-1, 3)) +
#     ggtitle("Andrews plot", sub = "This is a subtitle") +
#     theme_bw() +
#     scale_colour_brewer(palette = "Set1")
# 
# 
# drewcurves(iris[, c(sample(4), 5)], group = 5)
# 
# 
# 
# head(iris)
# 
# 
# drewcurves(iris[, -5])
# drewcurves(iris, group = 5)
# drewcurves(iris, group = 5, xlim = c(0, 2*pi))
# drewcurves(iris, group = 5) + ylim(c(-1, 3))
# drewcurves(iris[, c(sample(4), 5)], group = 5)
# 
# 
# str(iris)
# 
# iris[, names(iris)[5]]
# head(iris[, "Species"])
# 
# select(iris, Species)
# 
# ## ------------------------------------------
# 
# X <- iris[, -5]
# Y <- apply(X, 2, function(x) (x - min(x))/(max(x) - min(x)))
# t <- seq(-pi, pi, len = 100)
# group <- iris$Species
# 
# 
# 
# andrews(iris, clr = 5, ymax = 2.5)
# 
# 
# Z <- compute_fourier_series(Y, t, 1)
# 
# Z %>%
#   as.data.frame() %>%
#   # tbl_df() %>%
#   mutate(t = t) %>%
#   gather(key, value, -t) %>%
#   mutate(group = rep(group, each = nrow(Z))) %>%
#   ggplot(aes(t, value, group = key)) +
#   geom_line(aes(color = group))
# 
# 
# dim(Z)
# 
# 

